# LenSymphony - A simple music synthesizer library developed in Lens

This project provides a *Java* library for representing and synthesizing
musical pieces.
It allows users to define musical notes, silences, and staffs, and to
synthesize the sound of a complete musical piece using virtual instruments.

## Overview

This library is composed of the following classes:

```plantuml
hide empty members

' -------------------- '
' Note representations '
' -------------------- '

enum NoteValue {
    + {static} WHOLE
    + {static} HALF
    + {static} QUARTER
    + {static} EIGHTH
    + {static} SIXTEENTH
    + {static} THIRTY_SECOND
    + {static} SIXTY_FOURTH
    + {static} ONE_HUNDRED_TWENTY_EIGHTH
    + {static} TWO_HUNDRED_FIFTY_SIXTH
    - fractionOfWhole
    - type

    ~ NoteValue(fractionOfWhole: double, type: String)
    + duration(tempo: int): int
    + {static} fromString(type: String): NoteValue
}

enum PitchClass {
    + {static} C
    + {static} C_SHARP_D_FLAT
    + {static} D
    + {static} D_SHARP_E_FLAT
    + {static} E
    + {static} F
    + {static} F_SHARP_G_FLAT
    + {static} G
    + {static} G_SHARP_A_FLAT
    + {static} A
    + {static} A_SHARP_B_FLAT
    + {static} B

    + {static} fromName(name: String): PitchClass
}

class NotePitch {
    - {static} NB_OCTAVES: int
    - {static} NOTE_PITCHES: Map<PitchClass, NotePitch[]>
    - pitchClass: PitchClass
    - octave: int
    - frequency: double

    - NotePitch(pitchClass: PitchClass, octave: int, frequency: double)
    + {static} of(pitchClass: PitchClass, octave: int): NotePitch
    + {static} of(pitchClass: PitchClass, octave: int, alteration: int): NotePitch
    + alter(alteration: int): NotePitch
    + flat(): NotePitch
    + sharp(): NotePitch
    + frequency(): double
}

interface Note {
    + {abstract} getFrequency(): double
    + {abstract} getDuration(tempo: int): int
}

interface AbstractNoteFactory {
    + {abstract} createRest(value: NoteValue): Note
    + {abstract} createNote(pitch: NotePitch, value: NoteValue): Note
    + {abstract} createDottedNote(note: Note): Note
    + {abstract} createFermataOn(note: Note): Note
    + {abstract} createTiedNotes(notes: Note[]): Note
    + {abstract} createTiedNotes(notes: List<Note>): Note
}

class SimpleNoteFactory implements AbstractNoteFactory {
    - {static} INSTANCE: SimpleNoteFactory
    +getInstance(): SimpleNoteFactory
    +createNote(pitch: NotePitch, value: NoteValue): Note
    +createRest(value: NoteValue): Note
}

class NoteMusic implements Note {
    -pitch: NotePitch
    -value: NoteValue
    +NoteMusic(pitch: NotePitch, value: NoteValue)
    +getFrequency(): double
    +getDuration(tempo: int): int
}

class NoteSilence implements Note {
    -value: NoteValue
    +NoteSilence(value: NoteValue)
    +getFrequency(): double
    +getDuration(tempo: int): int
}

class DottedNote implements Note {
    - {const} mainNote: Note
    +DottedNote(mainNote: Note)
    +getFrequency(): double
    +getDuration(tempo: int): int
}

class TiedNote implements Note {
    - {const} note: List<Note>
    +TiedNote(note: List<Note>)
    +getFrequency(): double
    +getDuration(tempo: int): int
}

class MusicStaff {
    .. implements Iterable<Note> ..
    - {const} instrument: Instrument
    - {const} notes : List<Note>
    +MusicStaff(instrument: Instrument, volume: double)
    +addnote(note: Note): void
    +getInstrument(): Instrument
    +iterator():  Iterator<Note>
}

class MusicPiece {
    .. implements Iterable<MusicStaff> ..
    - tempo: int {readOnly}
    - staffs: List<MusicStaff>
    --
    + MusicPiece(tempo: int)
    + addStaff(staff: MusicStaff): void
    + getTempo(): int
    + getStaffs(): List<MusicStaff>
    +iterator():  Iterator<MusicStaff>
}

enum Instrument {
    PUR
    SYNTHESIZER
    VIOLIN
    PIANO
    GUITARE
    FLUTE
    CYMBALE
    SNARE
    BASS
    TRIANGLE
    TIMBALE
    XYLOPHONE
    --
    - synthesizer: NoteSynthesizer {readOnly}
    --
    + getSynthesizer(): NoteSynthesizer
}

class FermataNote implements Note {
    - note: Note
    - {static} {const} DURATION_PERCENTAGE: double
    + FermataNote(note: Note)
    + getFrequency(): double
    + getDuration(tempo: int): int
}

NotePitch o-- PitchClass
AbstractNoteFactory --> Note : << creates >>
MusicStaff --> Instrument : << uses >>

' ------- '
' Parsing '
' ------- '

class MusicXMLSaxParser {
    + MusicXMLSaxParser(noteFactory: AbstractNoteFactory)
    + getTempo(): int
    + getParts(): Map<String,List<Note>>
    + getNotes(partId: String): List<Note>
}

MusicXMLSaxParser --> AbstractNoteFactory : << uses >>

' --------------- '
' Sound synthesis '
' --------------- '

interface NoteSynthesizer {
    + {static} SAMPLE_RATE: int
    + {abstract} synthesize(note: Note, tempo: int, volume: double): double[]
}

interface MusicSynthesizer {
    + {abstract} synthesize(): void
    + {abstract} getSamples(): double[]
    + {abstract} getAudioData(): byte[]
    + {abstract} play(): void
    + {abstract} save(filename: String): void
}

class SimpleMusicSynthesizer implements MusicSynthesizer {
    - {static} DEFAULT_VOLUME: double
    - notes: Iterable<Note>
    - synthesizer: NoteSynthesizer
    - tempo: int
    - samples: double[]
    - staff: MusicStaff

    + SimpleMusicSynthesizer(staff: MusicStaff, tempo: int)
    + synthesize(): void
    + getSamples(): double[]
}

abstract AbstractSynthesize {
    # {const} decoratedSynthesizer: NoteSynthesizer
    # AbstractSynthesize(decoratedSynthesizer: NoteSynthesizer)
    + synthesize(note: Note, tempo: int, volume: double): double[]
}

class Synthesize extends AbstractSynthesize {
    - {static} {const} synthesize: Synthesize
    + {static} getInstance(): Synthesize
    + synthesize(note: Note, tempo: int, volume: double): double[]
}

class HarmonicSynthesize extends AbstractSynthesize {
    - {const} numberOfHarmonics: int
    - HarmonicSynthesize(decoratedSynthesizer: NoteSynthesizer,numberOfHarmonics: int)
    + synthesize(note: Note, tempo: int, volume: double): double[]
}

class CompositeMusicSynthesizer implements MusicSynthesizer {
    - {const} synthesizers: List<MusicSynthesizer>
    - samples: double[]
    + add(synthesizer: MusicSynthesizer): void
    + synthesize(): void
    + getSamples(): double[]
}

class SynthesizeFactory {
    + {static} createComposite(piece: MusicPiece): CompositeMusicSynthesizer
}

class ADSRSynthesizer extends AbstractSynthesize {
    - {const} a: double
    - {const} d: double
    - {const} s: double
    - {const} r: double
    - ADSRSynthesizer(decoratedSynthesizer: NoteSynthesizer, a: double, d: double, s: double, r: double)
    - ADSR(t: double, T: double): double
    + synthesize(note: Note, tempo: int, volume: double): double[]
}

class ComplexHarmonicSynthesizer extends AbstractSynthesize {
    - {const} numberOfHarmonics: int
    - {const} harmonicFunction: IntUnaryOperator
    - {const} amplitudeFunc: BiFunction<Integer, Double, Double>
    + ComplexHarmonicSynthesizer(decoratedSynthesizer: NoteSynthesizer, numberOfHarmonics: int, harmonicFunction: IntUnaryOperator, amplitudeFunc: BiFunction<Integer, Double, Double>)
    + synthesize(note: Note, tempo: int, volume: double): double[]
}

class NoiseSynthesize extends AbstractSynthesize {
    - {const} noiseLevel: double
    - random: Random
    + NoiseSynthesize(decoratedSynthesizer: NoteSynthesizer, noiseLevel: double)
    + synthesize(note: Note, tempo: int, volume: double): double[]
}

class VibratoSynthesizer extends AbstractSynthesize {
    - {const} depth: double
    - {const} speed: double
    + VibratoSynthesizer(decoratedSynthesizer: NoteSynthesizer, depth: double, speed: double)
    + synthesize(note: Note, tempo: int, volume: double): double[]
}

AbstractSynthesize <|-- ADSRSynthesizer
AbstractSynthesize <|-- ComplexHarmonicSynthesizer
AbstractSynthesize <|-- NoiseSynthesize
AbstractSynthesize <|-- VibratoSynthesizer
SimpleMusicSynthesizer o-- "*" Note
SimpleMusicSynthesizer o-- "1" NoteSynthesizer

' -------------------- '
' Command line parsing '
' -------------------- '

class CmdLine {
    - {static} INSTANCE: CmdLine
    - spec: CommandSpec
    - inputFile: String
    - outputFile: String
    - synthName: String
    - play: boolean
    - voiceMappings: List<String>
    - volumeMappings: List<String>
    - voices: Map<String, List<String>>
    - instrumentVolumes: Map<String, Double>
    + getInstance(): CmdLine
    + call(): Integer
    + processVoiceMappings(): void
    + processVolumeMappings(): void
    + getNoteInstance(): NoteSynthesizer
    + getInputFile(): String
    + getOutputFile(): String
    + shouldPlay(): boolean
    + convertVoice(voice: String): Instrument
    + getInstruments(partName: String): List<Instrument>
    + getVolumeForInstrument(instrument: Instrument): double
    + printSummary(): void
    + getVoiceMappings(): List<String>
    + setVoiceMappings(voiceMappings: List<String>): void
    + getVoices(): Map<String, List<String>>
    + getVolumeMappings(): List<String>
    + setVolumeMappings(volumeMappings: List<String>): void
    + getInstrumentVolumes(): Map<String, Double>
    + setInstrumentVolumes(instrumentVolumes: Map<String, Double>): void
}

CmdLine --> Instrument : << uses >>
CmdLine --> NoteSynthesizer : << uses >>

' --------------- '
' Percussion classes '
' --------------- '

class CymbaleSynthesizer {
    - {static} instance: CymbaleSynthesizer
    + {static} getInstance(): CymbaleSynthesizer
    + synthesize(note: Note, tempo: int, volume: double): double[]
}

class TriangleSynthesizer {
    - {static} instance: TriangleSynthesizer
    + {static} getInstance(): TriangleSynthesizer
    + synthesize(note: Note, tempo: int, volume: double): double[]
}

class TimbaleSynthesizer {
    - {static} instance: TimbaleSynthesizer
    + {static} getInstance(): TimbaleSynthesizer
    + synthesize(note: Note, tempo: int, volume: double): double[]
}

class SnareSynthesizer {
    - {static} instance: SnareSynthesizer
    + {static} getInstance(): SnareSynthesizer
    + synthesize(note: Note, tempo: int, volume: double): double[]
}

class BassSynthesizer {
    - {static} instance: BassSynthesizer
    + {static} getInstance(): BassSynthesizer
    + synthesize(note: Note, tempo: int, volume: double): double[]
}

class XylophoneSynthesizer {
    - {static} instance: XylophoneSynthesizer
    + {static} getInstance(): XylophoneSynthesizer
    + synthesize(note: Note, tempo: int, volume: double): double[]
}

XylophoneSynthesizer ..|> NoteSynthesizer
CymbaleSynthesizer ..|> NoteSynthesizer
TimbaleSynthesizer ..|> NoteSynthesizer
SnareSynthesizer ..|> NoteSynthesizer
BassSynthesizer ..|> NoteSynthesizer
TriangleSynthesizer ..|> NoteSynthesizer


' ------------ '
' Main classes '
' ------------ '

class Example {
    - {static} noteFactory: AbstractNoteFactory
    - {static} noteSynthesizer: NoteSynthesizer
    + {static} main(args: String[]): void
}

class LenSymphony {
    - {static} noteFactory: AbstractNoteFactory
    - {static} noteSynthesizer: NoteSynthesizer
    + {static} main(args: String[]): void
    + {static} createStaff(instrument: Instrument, notes: List<Note>, piece: MusicPiece, volume: double)
}

Example --> AbstractNoteFactory : << uses >>
Example --> MusicXMLSaxParser : << uses >>
Example --> NoteSynthesizer : << uses >>
LenSymphony --> AbstractNoteFactory : << uses >>
LenSymphony --> MusicXMLSaxParser : << uses >>
LenSymphony --> NoteSynthesizer : << uses >>
LenSymphony --> MusicPiece : << uses >>
LenSymphony --> MusicStaff : << uses >>
```

## Feature list

| Features                                               | Design Pattern(s) (?) | Author(s)       |
|--------------------------------------------------------|-----------------------|-----------------|
| Representation of a note's pitch (name + octave)       |                       |                 |
| Representation of a note/silence value                 |                       |                 |
| Representation of a musical note                       |                       | Pascal          |
| Representation of a silence                            |                       | Kilyan          |
| Representation of a point on a note                    | decorator             | Bryan           |
| Representation of a tie between notes                  |                       | kilyan          |
| Representation of a staff                              | iterator              | pascal          |
| Traversal of notes/silences in a staff                 |                       |                 |
| Representation of a musical piece                      | iterator              | tibot           |
| Creation of musical elements (notes, silences)         | Singleton / Factory   | Tibot           |
| Generation of the "pure" sound for a note              |                       | Bryan           |
| Addition of harmonics to the sound of a note           | Decorator             | Bryan           |
| Addition of complex harmonics to the sound of a note   | Decorator             | Pscal           |
| Application of an ADSR envelope to the sound of a note | Decorator             | Tibot           |
| Application of a vibrato to the sound of a note        | Decorator             | Kilyan          |
| Addition of random noise to the sound of a note        | Decorator             | Bryan           |
| Synthesis of the bass drum sound                       | Singleton             | Tibot           |
| Synthesis of the snare drum sound                      | Singleton             | Bryan           |
| Synthesis of the cymbal sound                          | Singleton             | Bryan           |
| Synthesis of the triangle sound                        | Singleton             | Pascal          |
| Synthesis of the timpani sound                         | Singleton             | Tibot           |
| Synthesis of the xylophone sound                       | Decorator             | Pascal          |
| Definition of virtual instruments                      |                       | pascal & kilyan |
| Synthesis of the ensemble piece sound                  |                       |                 |
| Command line management                                |                       | Pascal          |
| Multiple voice                                         | Composite             | Pascal          |
| Fermata                                                | Decorator             | Tibot           |
| New harmonic instrument                                |                       | Kilyan          |
| New instrument with ADSR, Vibrato ...                  |                       | Pascal          |

## Team

This project has been developed by:

- Bryan Detres
- Pascal Blondel
- Tibot Duquesne
- Kilyan Dubois
