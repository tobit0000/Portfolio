# *Pac-Man* en JavaFX

## Description

Ce projet fournit une implémentation de base du jeu *Pac-Man* en *JavaFX*.
Pour pouvoir développer votre propre implémentation de ce projet, vous devez
en créer une **divergence** en cliquant sur le bouton `Fork` en haut à droite
de cette page.

Lorsque ce sera fait, vous pourrez inviter les membres de votre groupe en tant
que *Developer* pour vous permettre de travailler ensemble sur ce projet.

## Consignes

Vous pouvez retrouver ci-dessous les liens vers les sujets de TP vous guidant
dans le développement de votre projet :

- [Lancement du projet](https://gitlab.univ-artois.fr/enseignements-rwa/modules/but-2/r3-04/tp/-/tree/main/tp/TP03)
- [Des patrons de conception dans *Pac-Man* (1)](https://gitlab.univ-artois.fr/enseignements-rwa/modules/but-2/r3-04/tp/-/tree/main/tp/TP04)
- [Des patrons de conception dans *Pac-Man* (2)](https://gitlab.univ-artois.fr/enseignements-rwa/modules/but-2/r3-04/tp/-/tree/main/tp/TP05)
- [Des patrons de conception dans *Pac-Man* (3)](https://gitlab.univ-artois.fr/enseignements-rwa/modules/but-2/r3-04/tp/-/tree/main/tp/TP06)
- [Bonnes pratiques de la POO dans le projet *Pac-Man*](https://gitlab.univ-artois.fr/enseignements-rwa/modules/but-2/r3-04/tp/-/tree/main/tp/TP07)

## Diagramme de classes

```plantuml
hide empty members

' --------------------------------------- '
' Gestion des images du jeu (les sprites) '
' --------------------------------------- '
interface IBonus {
    applyBonus(PacMan pacMan): void
}
class BonusPoints extends AbstractAnimated implements IBonus {
   + BonusPoints(game : PacmanGame, xPosition : double, yPosition : double, sprite : Sprite)
   + applyBonus(pacMan : PacMan): void
   + onCollisionWith(other : PacMan): void
}
class BonusSpeed extends AbstractAnimated implements IBonus {
   + BonusSpeed(game : PacmanGame, xPosition : double, yPosition : double, sprite : Sprite)
   + applyBonus(pacMan : PacMan): void
   + onCollisionWith(other : PacMan): void
}
class BonusSuper extends AbstractAnimated implements IBonus {
   - final bonuses : List<IBonus>
   + BonusSuper(game : PacmanGame, xPosition : double, yPosition : double, sprite : Sprite, bonuses : Ibonus...)
   + add(bonus : IBonus) : void
   + applyBonus(pacMan : PacMan): void
   + onCollisionWith(other : PacMan): void
}
interface ILevel{
	createMap(width: int, height: int, store: ISpriteStore): GameMap
	getBonuses(): List<String>
	configureGhosts(ghosts : List<Ghost>, player: PacMan): void
	changeLevel(): ILevel
}
class LevelEasy implements ILevel{
  - final {static} INSTANCE : LevelEasy
  + {static} getInstance(): LevelEasy
  - LevelEasy()
  + createMap(width: int, height: int, store: ISpriteStore): GameMap
  + getBonuses(): List<String>
  + configureGhosts(ghosts: List<Ghost>, player: PacMan): void  
  + changeLevel(): ILevel
}
class LevelFactory{
  + {static} getLevel(number: int): ILevel
}
class LevelHard implements ILevel{
  - final {static} INSTANCE : LevelHard
  + {static} getInstance(): LevelHard
  - LevelHard()
  + createMap(width: int, height: int, store: ISpriteStore): GameMap
  + getBonuses(): List<String>
  + configureGhosts(ghosts: List<Ghost>, player: PacMan): void  
  + changeLevel(): ILevel
}
class LevelMedium implements ILevel{
  - final {static} INSTANCE : LevelMedium
  + {static} getInstance(): LevelMedium
  - LevelMedium()
  + createMap(width: int, height: int, store: ISpriteStore): GameMap
  + getBonuses(): List<String>
  + configureGhosts(ghosts: List<Ghost>, player: PacMan): void  
  + changeLevel(): ILevel
}
abstract class Sprite {
    - imageProperty : ObjectBinding<Image>

    # Sprite(imageProperty : ObjectBinding<Image>)
    + getWidth() : int
    + getHeight() : int
    + imageProperty() : ObjectBinding<Image>
    + {abstract} destroy() : void
}

class StaticSprite extends Sprite {
    - StaticSprite(imageProperty : ObjectBinding<Image>)
    + {static} newInstance(image : Image) : Sprite
    + destroy() : void
}

class AnimatedSprite extends Sprite {
    - timeline : Timeline

    - AnimatedSprite(imageProperty : ObjectBinding<Image>, timeline : Timeline)
    + {static} newInstance(images : ObservableList<Image>, frameRate : int) : Sprite
    + destroy() : void
}

interface ISpriteStore {
    + {static} DEFAULT_SPRITE_SIZE : int
    + {static} DEFAULT_FRAME_RATE : int

    + {abstract} getSprite(identifier : String) : Sprite
    + getSprite(identifiers : String[]) : Sprite
    + getSprite(frameRate : int, identifiers : String[]) : Sprite
    + getSprite(identifiers : List<String>) : Sprite
    + {abstract} getSprite(frameRate : int, identifiers : List<String>) : Sprite
    + getSpriteSize() : int
}

class SpriteStore implements ISpriteStore {
    - spriteCache : Map<String, Sprite>

    + getSprite(identifier : String) : Sprite
    + getSprite(frameRate : int, identifiers : List<String>) : Sprite
    - loadImage(name : String) : Image
}

ISpriteStore --> Sprite : << crée >>

' -------------------------- '
' Gestion de la carte du jeu '
' -------------------------- '
interface IGenMap{
  generateMap(width: int, height: int, spriteStore: ISpriteStore): GameMap
}
class GameMap {
    - height : int
    - width : int
    - cells : Cell[][]

    + GameMap(height : int, width : int)
    - init() : void
    + getHeight() : int
    + getWidth() : int
    + isOnMap(row : int, column : int) : boolean
    + getAt(row : int, column : int) : Cell
    + setAt(row : int, column : int, cell : Cell) : void
    + getEmptyCells() : List<Cell>
}

class Cell {
    - row : int
    - column : int
    - spriteProperty : ObjectProperty<Sprite>
    - wallProperty : ObjectProperty<Wall>
    - imageProperty : ObjectProperty<Image>

    # Cell(row : int, column : int)
    + Cell(sprite : Sprite)
    + Cell(wall : Wall)
    + getRow() : int
    + getColumn() : int
    + getWidth() : int
    + getHeight() : int
    + isEmpty() : boolean
    + getSprite() : Sprite
    + spriteProperty() : ObjectProperty<Sprite>
    + getWall() : Wall
    + wallProperty() : ObjectProperty<Wall>
    + imageProperty() : ObjectProperty<Image>
    + replaceBy(cell : Cell) : void
}
class GenMap implements IGenMap{
  - final {static} INSTANCE: GenMap
  + {static} getInstance(): GenMap
  - GenMap()
  + generateMap(width: int, height: int, spriteStore: ISpriteStore): GameMap
}
class RegularGenMap implements IGenMap {
  map: IGenMap
  + RegularGenMap(map IGenMap)
  + generateMap(width: int, height: int, spriteStore: ISpriteStore): GameMap
}
class Wall {
    - sprite : Sprite

    + Wall(sprite : Sprite)
    + getSprite() : Sprite
}

GameMap *-- "*" Cell

Cell o-- "1" Wall
Cell o-- "1" Sprite

Wall o-- "1" Sprite

' -------------------- '
' Gestion de la partie '
' -------------------- '

class PacmanGame {
    + {static} RANDOM : Random
    + {static} DEFAULT_SPEED : int
    - width : int
    - height : int
    - spriteStore : ISpriteStore
    - gameMap : GameMap
    - player : IAnimated
    - nbGhosts : int
    - nbGums : int
    - movingObjects : List<IAnimated>
    - animatedObjects : List<IAnimated>
    - animation : AnimationTimer
    - controller : IPacmanController

    + PacmanGame(gameWidth : int, gameHeight : int, spriteStore : ISpriteStore, nbGhosts : int)
    + setController(controller : IPacmanController) : void
    + getSpriteStore() : ISpriteStore
    + getWidth() : int
    + getHeight() : int
    + prepare() : void
    + start() : void
    - createMap() : GameMap
    - createAnimated() : void
    - initStatistics() : void
    - spawnAnimated(animated : IAnimated): void
    + moveUp() : void
    + moveRight() : void
    + moveDown() : void
    + moveLeft() : void
    + stopMoving() : void
    - getCellOf(animated : IAnimated) : Cell
    + getCellAt(x : int, y : int) : Cell
    + addMoving(object : IAnimated) : void
    + addAnimated(object : IAnimated) : void
    + removeAnimated(object : IAnimated) : void
    - clearAnimated() : void
    + pacGumEaten(gum : IAnimated) : void
    + playerIsDead() : void
    - gameOver(message : String) : void
}

interface IAnimated {
    + {abstract} getWidth() : int
    + {abstract} getHeight() : int
    + {abstract} setX(xPosition : double) : void
    + {abstract} getX() : int
    + {abstract} xProperty() : DoubleProperty
    + {abstract} setY(yPosition : double) : void
    + {abstract} getY() : int
    + {abstract} yProperty() : DoubleProperty
    + {abstract} setHorizontalSpeed(speed : double) : void
    + {abstract} getHorizontalSpeed() : double
    + {abstract} setVerticalSpeed(speed : double) : void
    + {abstract} getVerticalSpeed() : double
    + {abstract} setSprite(sprite : Sprite) : void
    + {abstract} getSprite() : Sprite
    + {abstract} spriteProperty() : ObjectProperty<Sprite>
    + {abstract} imageProperty() : ObjectProperty<Image>
    + {abstract} setDestroyed(destroyed : boolean) : void
    + {abstract} isDestroyed() : boolean
    + {abstract} destroyedProperty() : BooleanProperty
    + {abstract} onCreation() : void
    + {abstract} onSpawn() : void
    + {abstract} onStep(timeDelta : long) : boolean
    + {abstract} isCollidingWith(other : IAnimated) : boolean
    + {abstract} onCollisionWith(other : IAnimated) : void
    + {abstract} onDespawn() : void
    + {abstract} onDestruction() : void
    + {abstract} self() : IAnimated
}

interface IPacmanController {
    + {abstract} setGame(game : PacmanGame) : void
    + {abstract} prepare(map : GameMap) : void
    + {abstract} bindScore(scoreProperty : IntegerExpression) : void
    + {abstract} bindLife(lifeProperty : IntegerExpression) : void
    + {abstract} addAnimated(movable : IAnimated) : void
    + {abstract} gameOver(endMessage : String) : void
    + {abstract} reset() : void
}

class GameAnimation {
    - previousTimestamp : long
    - movingObjects : List<IAnimated>
    - animatedObjects : List<IAnimated>

    + GameAnimation(movingObjects : List<IAnimated>, animatedObjects : List<IAnimated>)
    + start(): void
    + handle(now : long) : void
    - updateObjects(delta : long) : void
    - checkCollisions() : void
}

PacmanGame o-- "1" ISpriteStore
PacmanGame o-- "1" GameMap
PacmanGame o-- "*" IAnimated
PacmanGame o-- "1" GameAnimation
PacmanGame o-- "1" IPacmanController

GameAnimation o-- "*" IAnimated

' --------------------------------- '
' Gestion de base des objets animés '
' --------------------------------- '

abstract class AbstractAnimated implements IAnimated {
    - {static} MARGIN : int
    # game : PacmanGame
    # xPosition : DoubleProperty
    # yPosition : DoubleProperty
    # horizontalSpeed : double
    # verticalSpeed : double
    # destroyed : BooleanProperty
    # sprite : ObjectProperty<Sprite>
    # image : ObjectProperty<Image>

    # AbstractAnimated(game : PacmanGame, xPosition : double, yPosition : double, sprite : Sprite)
    + getWidth() : int
    + getHeight() : int
    + setX(xPosition : double) : void
    + getX() : int
    + xProperty() : DoubleProperty
    + setY(yPosition : double) : void
    + getY() : int
    + yProperty() : DoubleProperty
    + setHorizontalSpeed(speed : double) : void
    + getHorizontalSpeed() : double
    + setVerticalSpeed(speed : double) : void
    + getVerticalSpeed() : double
    + setSprite(sprite : Sprite) : void
    + getSprite() : Sprite
    + spriteProperty() : ObjectProperty<Sprite>
    + imageProperty() : ObjectProperty<Image>
    + setDestroyed(destroyed : boolean) : void
    + isDestroyed() : boolean
    + destroyedProperty() : BooleanProperty
    + onCreation() : void
    + onSpawn() : void
    + onStep(delta : long) : boolean
    - isOnWall(x : int, y : int) : boolean
    + isCollidingWith(other : IAnimated) : boolean
    + onDespawn() : void
    + onDestruction() : void
    + self() : IAnimated
    + hashCode() : int
    + equals(obj : Object) : boolean
}

AbstractAnimated o-- "1" PacmanGame
AbstractAnimated o-- "1" Sprite

interface InterfaceDeplacementStrategie{
  deplacerGhost(ghost: Ghost, pacman: PacMan, delta: long, speed: int): void
}
interface GhostState{
  changeState(): GhostState
  makeDamage(pacman: PacMan): void
  onStep(delta: long): boolean
  getSpeed(): int
}
interface PacManState{
  + makeDamage(): void
  + changeState(): PacManState
  onStep(delta: long): boolean
  isVulnerable(): boolean
  getSpeed(): int
  getPoints(): int
}
class PacMan extends AbstractAnimated{
  - health: IntegerProperty
  - score: IntegerProperty
  - state: PacmanState
  - desiredDirection: String
  + PacMan(game: PacmanGame, xPosition: double, yPosition: double, sprite: Sprite)
  + setDesiredDirection(desiredDirection: String): void
  + onStep(delta: long): boolean
  + getHealth(): int
  + getSpeed(): int
  + getScore(): int
  + getHealthProperty(): IntegerProperty
  + getScoreProperty(): IntegerProperty
  + onCollisionWith(other: IAnimated): void
  + changeState(state1: PacmanState): void
  + onCollisionWith(other: Ghost): void
  + makeDamage(): void
  + onCollisionWith(gum: PacGomme): void
  + onCollisionWith(gum: MegaGomme): void
  + onCollisionWith(bonus: IBonus): void
  + onEatenGhost(): void
}
class DeplacementAleatoireStrategie implements InterfaceDeplacementStrategie {
  - final random: Random
  deplacerGhost(ghost: Ghost, pacman: PacMan, delta: long, speed: int): void
}
class DeplacementAlt implements InterfaceDeplacementStrategie {
  - final {static} INSTANCE: DeplacementAlt
  + {static} getInstance(): DeplacementAlt
  - DeplacementAlt()
  deplacerGhost(ghost: Ghost, pacman: PacMan, delta: long, speed: int): void
}
class DeplacementBlinky implements InterfaceDeplacementStrategie {
  deplacerGhost(ghost: Ghost, pacman: PacMan, delta: long, speed: int): void
}
class DeplacementInky implements InterfaceDeplacementStrategie {
  - final {static} INSTANCE: DeplacementInky
  + {static} getInstance(): DeplacementInky
  - DeplacementInky()
  deplacerGhost(ghost: Ghost, pacman: PacMan, delta: long, speed: int): void
}
class DeplacementPinky implements InterfaceDeplacementStrategie {
  - final {static} INSTANCE: DeplacementPinky
  + {static} getInstance(): DeplacementPinky
  - DeplacementPinky()
  deplacerGhost(ghost: Ghost, pacman: PacMan, delta: long, speed: int): void
}
class Ghost extends AbstractAnimated{
  - id: int
  - timer: AnimationTimer
  - intervalSeconds: double
  - action: Runnable
  - accumulator: double
  - strategie: InterfaceDeplacementStrategie
  - oldStrategie: InterfaceDeplacementStrategie
  - state: GhostState
  - originalSprite: Sprite
  + Ghost(game: PacmanGame, xPosition: double, yPosition: double, sprite: Sprite, id: int)
  + getID(): int
  + start(): void
  + setAction(action: Runnable): void
  + stop(): void
  + changeState(state1: GhostState): void
  + setOriginalSprite(originalSprite: Sprite): void
  + getOriginalSprite(): Sprite
  + setSkins(skins: String[]): void
  + setStrategie(strategie: InterfaceDeplacementStrategie): void
  + getStrategie(): InterfaceDeplacementStrategie
  + setOldStrategie(oldStrategie: InterfaceDeplacementStrategie): void
  + getOldStrategie(): InterfaceDeplacementStrategie
  + deplacerFantome(delta: long, pacman: Pacman): void
  + onCollisionWith(other: Pacman): void
  + makeDamage(pacman: Pacman): void
  + onStep(delta: long): boolean
  + getSpeed(): int
}
class GhostEndVulnerableState implements GhostState {
  - skins[]: String
  - ghost: Ghost
  - final {static} END_VULNERABLE_DURATION: int
  - elapsedTime: double
  + GhostEndVulnerableState(ghost: Ghost)
  + onStep(delta: long): boolean
  + makeDamage(pacman: PacMan): void
  + changeState(): GhostState
  + getSpeed(): int
}
class GhostInvulnerableState implements GhostState {
  - ghost: Ghost
  + GhostInvulnerableState(ghost: Ghost)
  + onStep(delta: long): boolean
  + makeDamage(pacman: PacMan): void
  + changeState(): GhostState
  + getSpeed(): int
}
class GhostRunState implements GhostState{
  - skins[]: String
  - ghost: Ghost
  - final {static} RUN_DURATION: int
  - elapsedTime: double
  + GhostRunState(ghost: Ghost)
  + onStep(delta: long): boolean
  + makeDamage(pacman: PacMan): void
  + changeState(): GhostState
  + getSpeed(): int
}
class GhostSpeedState implements GhostState{
  - ghost: Ghost
  - final {static} END_VULNERABLE_DURATION: int
  - elapsedTime: double
  + GhostSpeedState(ghost: Ghost)
  + changeState(): GhostState
  + onStep(delta: long): boolean
  + makeDamage(pacman: PacMan): void
  + getSpeed(): int
}
class GhostVulnerableState implements GhostState{
  - skins[]: String
  - finale {static} VULENRABLE_DURATION: int
  - ghost: Ghost
  - elapsedTime: double
  + GhostVulnerableState(ghost: Ghost)
  + onStep(delta: long): boolean
  + makeDamage(pacman: PacMan): void
  + changeState(): GhostState
  + getSpeed(): int
}
class InvulnerableState implements PacmanState{
  pacman: PacMan
  - final {static} DURATION: int
  - elapsedTime: double
  + InvulnerableState(pacman: PacMan)
  + onStep(delta: long): boolean
  + changeState(): PacmanState
  + makeDamage(): void
  + isVulnerable(): boolean
  + getSpeed(): int
  + getPoints(): int
}
class MegaGomme extends AbstractAnimated{
  + {static} final POINTS: int
  + MegaGomme(game: PacmanGame, xPosition: double, yPosition: double, spriteStore: Sprite)
  + onCollisionWith(other: PacMan): void
}
class PacGomme extends AbstractAnimated{
  + {static} final POINTS: int
  PacGomme(game: PacmanGame, xPosition: double, yPosition: double, spriteStore: Sprite)
  + onCollisionWith(other: PacMan): void
}
class PointsState implements PacManState{
  pacman: PacMan
  - final {static} DURATION: int
  - elapsedTime: double
  + PointsState(pacman: PacMan)
  + makeDamage(): void
  + onStep(delta: long): boolean
  + changeState(): PacManState
  + isVulnerable(): boolean
  + getSpeed(): int
  + getPoints(): int
}
class SpeedState implements PacManState{
  pacman: PacMan
  - final {static} DURATION: int
  - elapsedTime: double
  + SpeedState(pacman: PacMan)
  + makeDamage(): void
  + onStep(delta: long): boolean
  + changeState(): PacManState
  + isVulnerable(): boolean
  + getSpeed(): int
  + getPoints(): int
}
class SuperState implements PacManState{
  pacman: PacMan
  - final {static} DURATION: int
  - elapsedTime: double
  + SuperState(pacman: PacMan)
  + makeDamage(): void
  + onStep(delta: long): boolean
  + changeState(): PacManState
  + isVulnerable(): boolean
  + getSpeed(): int
  + getPoints(): int
}
class VulenrableState implements PacManState{
  pacman: PacMan
  skins: String[]
  + VulenrableState(pacman: PacMan)
  + makeDamage(): void
  + onStep(delta: long): boolean
  + changeState(): PacManState
  + isVulnerable(): boolean
  + getSpeed(): int
  + getPoints(): int
}
class BonusGhostSpeed extends AbstractAnimated implements IBonus{
  # BonusGhostSpeed(game: PacmanGame, xPosition: double, yPosition: double, sprite: Sprite)
  + applyBonus(pacMan: PacMan): void
  + applyBonus(ghost: Ghost): void
}
' ----------------- '
' Contrôleur JavaFX '
' ----------------- '

class PacmanController implements IPacmanController {
    - game : PacmanGame
    - stage : Stage
    - backgroundPane : GridPane
    - animatedPane : Pane
    - message : Label
    - score : Label
    - life : Label
    - started : boolean

    + setGame(game : PacmanGame) : void
    + setStage(stage : Stage) : void
    - addKeyListeners() : void
    + prepare(map : GameMap) : void
    - createBackground(map : GameMap) : void
    + bindScore(scoreProperty : IntegerExpression) : void
    + bindLife(lifeProperty : IntegerExpression) : void
    + addAnimated(animated : IAnimated) : void
    + gameOver(endMessage : String) : void
    + reset() : void
}

PacmanController o-- "1" PacmanGame
```

## Tâches réalisées

### Jalon n°1 - TP n°3

| Fonctionnalité                             | Terminée ? | Auteur(s) |
| ------------------------------------------ |------------|-----------|
| Gestion des collisions spécifiques         | X          | Tibot     |
| Représentation des pac-gommes              | X          | Tibot     |
| Représentation de Pac-Man                  | X          | Pascal    |
| Intégration de Pac-Man dans la partie      | X          | Pascal    |
| Représentation des fantômes                | X          | Kilyan    |
| Intégration des fantômes dans la partie    | X          | Kilyan    |
| Création de la carte du jeu                | X          | Bryan     |
| Ajout des pac-gommes sur la carte          | X          | Bryan     |

### Jalon n°2 - TP n°4

| Fonctionnalité                             | Patron de Conception ? | Terminée ? | Auteur(s)    |
|--------------------------------------------|------------------------|------------|--------------|
| Variantes de génération de labyrinthe      | Strategie/singleton    | X          | Bryan        |
| Mur autour de la map                       |                        | X          | Bryan        |
| Complétion d'un labyrinthe existant        | Decorateur             | X          | Pascal       |
| Mur horizontal dans le la map              |                        | X          | Pascal       |
| Variantes de déplacement pour les fantômes | Strategie              | X          | Tibot/Kilyan |
| Déplacement de Blinky                      | singleton              | X          | Kilyan       |
| Déplacement de Pinky                       | singleton              | X          | Tibot        |
| Déplacement de Inky                        | singleton              | X          | Tibot        |
| Déplacement de Clyde                       | singleton              | X          | Kilyan       |

### Jalon n°3 - TP n°5

| Fonctionnalité                             | Patron de Conception ? | Terminée ?  | Auteur(s)                                     |
| ------------------------------------------ | ---------------------- | ----------- | --------------------------------------------- |
| Pac-Man vulnérable                         |            state       |      X      |        tibot                                  |
| Pac-Man invulnérable                       |            state       |      X      |        Bryan                                  |
| Fantômes vulnérables                       |            state       |      X      |        pascal                                 |
| Fantômes fuyants                           |            state       |      X      |        pascal                                 |
| Fantômes presque invulnérables             |            state       |      X      |        pascal                                 |
| Fantômes invulnérables                     |            state       |      X      |        pascal                                 |
| Réutilisation des fantômes existants       |                        |      X      |        pascal                                 |
| Ajout des méga-gommes                      |                        |      X      |        kilyan                                 |

### Jalon n°4 - TP n°6

| Fonctionnalité                                       | Patron de Conception ? | Terminée ? | Auteur(s)                                     |
| ---------------------------------------------------- | ---------------------- | ---------- | --------------------------------------------- |
| Définition d'un seul `SpriteStore`                   |    singleton           |     X      |      pascal                                   |
| Définition d'une seule instance quand c'est possible |    singleton           |     X      |      pascal                                   |
| Ajout des bonus (vitesse)                            |                        |     X      |      bryan                                    |
| Ajout des bonus (point)                              |                        |     X      |      bryan                                    |
| Ajout des bonus multiples                            |     composite          |     X      |      bryan                                    |
| Gestion des différents niveaux                       | factory/state/singleton|     X      |      tibot/kylian                             |


### Jalon n°5 - TP n°7

| Fonctionnalité                             | Patron de Conception ? | Terminée ? | Auteur(s)                                     |
| ------------------------------------------ | ---------------------- | ---------- | --------------------------------------------- |
| Correction des avertissements              |                        |      X      |           pascal                             |
| Correction des défauts sur *SonarQube*     |                        |      X      |           bryan                              |
| Rangement des classes en paquetages        |                        |      X      |           kylian                             |
| Modularisation du projet                   |                        |      X      |           tibot                              |
