package fr.univartois.butinfo.ihm.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import fr.univartois.butinfo.ihm.controller.IBomberController;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.util.Duration;

public class ControllerFacade {
	IBomberController bomber;
	GameMap map;
	Timeline timeline;
	Player player;
	ObservableList<Enemy> enemyList = FXCollections.observableArrayList();
	ObservableList<AbstractBomb> bombList = FXCollections.observableArrayList();
	
	public static Random rand = new Random();
	public static final int MAX_HAUTEUR = 19;
	public static final int MAX_LARGEUR = 19;
	public static final int NB_ENEMY = 5;
	public static final int NB_WALLS = 6;
	
	public void setController(IBomberController bomber) {
		this.bomber = bomber;
	}
	
	public void startGame() {
		player = new Player(this);
		
		List<String> characterSkins = new ArrayList<String>();
		characterSkins.add("/fr/univartois/butinfo/ihm/images/punker.png");
		characterSkins.add("/fr/univartois/butinfo/ihm/images/rourke.png");
		characterSkins.add("/fr/univartois/butinfo/ihm/images/minotaur.png");
		characterSkins.add("/fr/univartois/butinfo/ihm/images/goblin.png");
    	
		enemyList.clear();
		bombList.clear();
		player.getBombProp().clear(); 
		
    	for (int i = 0; i < 10; ++i) {
    		Bomb bomb = new Bomb(this);
    		player.getBombProp().add(bomb);
    		bombList.add(bomb);
    	}
    	
    	for (int i = 0; i < 2; ++i) {
    		LargeBomb bombLarge = new LargeBomb(this);
    		player.getBombProp().add(bombLarge);
    		bombList.add(bombLarge);
    	}
    	
    	bomber.updateBomb(player);
		
		map = GameMapFactory.createMapWithRandomBrickWalls(MAX_HAUTEUR, MAX_LARGEUR, NB_WALLS);
		
		for (int i = 0; i < NB_ENEMY; ++i) {
			Enemy enemy = new Enemy(this, "Name");
			placePlayer(enemy);
			enemy.animate();
			
			enemyList.add(enemy);
			
			int randInt = rand.nextInt(0, 3);
			this.bomber.updatePlayer(enemy, characterSkins.get(randInt));
		}
		
		this.bomber.initialize(map);
		placePlayer(player);
		this.bomber.updatePlayer(player, "/fr/univartois/butinfo/ihm/images/guy.png");
		this.bomber.updateVie(player);
		this.bomber.updateEnemyNumber(enemyList);
		this.bomber.saveBomb(player.getBombProp());
		
	}
	
	public void removeEnemy(Enemy enemy) {
		enemyList.remove(enemy);
	}
	
	public void finishGame() {
		this.bomber.finishGame();
	}
	
	public void poseBomb() {
		poseBomb(0);
	}
	
	public void explode(int row, int column) {
		if (row >= 0 && row < MAX_LARGEUR && column >= 0 && column < MAX_HAUTEUR) {
			Tile tile = map.get(row, column);
			
			List<Enemy> toDamage = new ArrayList<>();

			for (Enemy enemy : enemyList) {
			    if (enemy.getRow() == row && enemy.getColumn() == column) {
			        toDamage.add(enemy);
			    }
			}

			// évite un bug de ConcurrentModificationException
			for (Enemy e : toDamage) {
			    e.decHealth();
			}
			
			if (player.getRow() == row && player.getColumn() == column) {
				player.decHealth();
			}
			
			tile.explode();
		}
	}
	
	public void poseBomb(int index) {
		int size = player.getBombProp().size();
		if (size > 0) {
			AbstractBomb bomb = player.getBomb(index);
			bomb.setPosition(player.getRow(), player.getColumn());
			bomber.afficherBomb(player, bomb);
			player.removeBomb(index);
			
		    this.timeline = new Timeline(
			        new KeyFrame(Duration.seconds(bomb.getDelay()), e -> bomb.explode()));
			    this.timeline.setCycleCount(1);
			    this.timeline.play();
		}
	}

	
	public void placePlayer(AbstractCharacter character) {
		List<Tile> tileList = map.getEmptyTiles();
		int rnd = rand.nextInt(tileList.size());
		Tile tile = tileList.get(rnd);
		character.setPosition(tile.getRow(), tile.getColumn());
	}
	
	public void moveUp(AbstractCharacter character) {
		int row = character.getRow()-1;
		int column = character.getColumn();
		Tile tile = map.get(row, column);
		if (tile.getContent().getName().equals("lawn")) {
			character.setPosition(row, column);
		}
	}
	
	public void moveDown(AbstractCharacter character) {
		int row = character.getRow()+1;
		int column = character.getColumn();
		Tile tile = map.get(row, column);
		if (tile.getContent().getName().equals("lawn")) {
			character.setPosition(row, column);
		}
	}
	
	public void moveRight(AbstractCharacter character) {
		int row = character.getRow();
		int column = character.getColumn()+1;
		Tile tile = map.get(row, column);
		if (tile.getContent().getName().equals("lawn")) {
			character.setPosition(row, column);
		}
	}
	
	public void moveLeft(AbstractCharacter character) {
		int row = character.getRow();
		int column = character.getColumn()-1;
		Tile tile = map.get(row, column);
		if (tile.getContent().getName().equals("lawn")) {
			character.setPosition(row, column);
		}
	}
	
	public void moveUp() {
		moveUp(player);
	}
	
	public void moveRight() {
		moveRight(player);
	}
	
	public void moveLeft() {
		moveLeft(player);
	}
	
	public void moveDown() {
		moveDown(player);
	}
}
