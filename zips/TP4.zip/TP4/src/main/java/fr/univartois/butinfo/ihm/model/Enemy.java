/**
 * Ce logiciel est distribué à des fins éducatives.
 *
 * Il est fourni "tel quel", sans garantie d'aucune sorte, explicite
 * ou implicite, notamment sans garantie de qualité marchande, d'adéquation
 * à un usage particulier et d'absence de contrefaçon.
 * En aucun cas, les auteurs ou titulaires du droit d'auteur ne seront
 * responsables de tout dommage, réclamation ou autre responsabilité, que ce
 * soit dans le cadre d'un contrat, d'un délit ou autre, en provenance de,
 * consécutif à ou en relation avec le logiciel ou son utilisation, ou avec
 * d'autres éléments du logiciel.
 *
 * (c) 2022-2025 Romain Wallon - Université d'Artois.
 * Tous droits réservés.
 */
package fr.univartois.butinfo.ihm.model;


import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.util.Duration;

/**
 * La classe Enemy représente un adversaire du joueur dans le jeu du Bomberman.
 *
 * @author Romain Wallon
 *
 * @version 0.1.0
 */
public class Enemy extends AbstractCharacter {

    /**
     * Le nom de ce personnage.
     */
    private final String name;
    Timeline timeline;

    /**
     * Construit un nouvel Enemy.
     *
     * @param name Le nom du personnage.
     */
    public Enemy(ControllerFacade facade, String name) {
        super(facade, 1);
        this.name = name;
    }

    public void decHealth() {
    	super.decHealth();
    	if (this.getHealth() <= 0) {
    		timeline.stop();
    		facade.removeEnemy(this);
    	}
    	
    }
    
    /*
     * (non-Javadoc)
     *
     * @see fr.univartois.butinfo.ihm.bomberman.model.AbstractCharacter#getName()
     */
    @Override
    public String getName() {
        return name;
    }
    
    public void randomDirection() {
    	int randInt = ControllerFacade.rand.nextInt(0, 4);
    	switch (randInt) {
    	case 0:
    		facade.moveUp(this);
    		break;
    	case 1:
    		facade.moveLeft(this);
    		break;
    	case 2:
    		facade.moveRight(this);
    		break;
    	case 3:
    		facade.moveDown(this);
    		break;
    	}
    }
    
	public void animate() {
	    this.timeline = new Timeline(
	        new KeyFrame(Duration.seconds(1), e -> randomDirection()));
	    this.timeline.setCycleCount(Animation.INDEFINITE);
	    this.timeline.play();
	}

}
