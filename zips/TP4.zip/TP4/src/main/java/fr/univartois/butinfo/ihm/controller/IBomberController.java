package fr.univartois.butinfo.ihm.controller;

import fr.univartois.butinfo.ihm.model.AbstractBomb;
import fr.univartois.butinfo.ihm.model.AbstractCharacter;
import fr.univartois.butinfo.ihm.model.ControllerFacade;
import fr.univartois.butinfo.ihm.model.Enemy;
import fr.univartois.butinfo.ihm.model.GameMap;
import fr.univartois.butinfo.ihm.model.Player;
import javafx.collections.ObservableList;

public interface IBomberController {
	void initialize(GameMap map);
	void setFacade(ControllerFacade facade);
	void updatePlayer(AbstractCharacter player, String url);
	void updateBomb(Player player);
	void afficherBomb(Player player, AbstractBomb bomb);
	void finishGame();
	void updateVie(Player player);
	void updateEnemyNumber(ObservableList<Enemy> enemyList);
	void saveBomb(ObservableList<AbstractBomb> bombList);
}
