/**
 * Ce logiciel est distribué à des fins éducatives.
 *
 * Il est fourni "tel quel", sans garantie d'aucune sorte, explicite
 * ou implicite, notamment sans garantie de qualité marchande, d'adéquation
 * à un usage particulier et d'absence de contrefaçon.
 * En aucun cas, les auteurs ou titulaires du droit d'auteur ne seront
 * responsables de tout dommage, réclamation ou autre responsabilité, que ce
 * soit dans le cadre d'un contrat, d'un délit ou autre, en provenance de,
 * consécutif à ou en relation avec le logiciel ou son utilisation, ou avec
 * d'autres éléments du logiciel.
 *
 * (c) 2022-2025 Romain Wallon - Université d'Artois.
 * Tous droits réservés.
 */

package fr.univartois.butinfo.ihm.controller;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;

import fr.univartois.butinfo.ihm.model.AbstractBomb;
import fr.univartois.butinfo.ihm.model.AbstractCharacter;
import fr.univartois.butinfo.ihm.model.ControllerFacade;
import fr.univartois.butinfo.ihm.model.Enemy;
import fr.univartois.butinfo.ihm.model.GameMap;
import fr.univartois.butinfo.ihm.model.Player;
import fr.univartois.butinfo.ihm.model.Tile;
import javafx.beans.binding.Bindings;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

/**
 * La classe HelloController illustre le fonctionnement du contrôleur associé à une vue.
 *
 * @author Romain Wallon
 *
 * @version 0.1.0
 */
public class BomberController implements IBomberController {

    /**
     * Le label de l'application, où l'on va pouvoir afficher des messages.
     * Cet attribut sera initialisé automatiquement par JavaFX grâce à l'annotation {@link FXML}.
     */
    @FXML
    private Label bombLab;

    @FXML
    private Label ennemiLab;

    @FXML
    private Label pvLab;
    
    @FXML
    private GridPane grid;
    
    @FXML
    private Pane pane;
    
    private ControllerFacade facade;
    private Scene scene;
    private Stage stage;
    private boolean finishedGame = false;
    private ObservableList<AbstractBomb> bombListCT;
    
    public void setScene(Scene scene) {
    	this.scene = scene;
    	scene.addEventFilter(KeyEvent.KEY_PRESSED, e -> {
    		if (!finishedGame) {
	    		if (e.getCode() == KeyCode.UP) {
	    			facade.moveUp();
	    		}
	    		else if (e.getCode() == KeyCode.LEFT) {
	    			facade.moveLeft();
	    		}
	    		else if (e.getCode() == KeyCode.RIGHT) {
	    			facade.moveRight();
	    		}
	    		else if (e.getCode() == KeyCode.DOWN) {
	    			facade.moveDown();
	    		}
	    		else if (e.getCode() == KeyCode.E) {
	    			facade.poseBomb();
	    		}
    		}
    		});

    }

    public void setStage(Stage stage) {
    	this.stage = stage;
    }
    
    public void setFacade(ControllerFacade facade) {
    	this.facade = facade;
    }
    
    @FXML
    public void afficheInventaire() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/univartois/butinfo/ihm/view/choice-bomb-view.fxml"));
        Parent viewContent = fxmlLoader.load();
        
        Scene newScene = new Scene(viewContent);
        stage.setScene(newScene);
        
        ChoiceBombController controller2 = fxmlLoader.getController();
        
        controller2.setFacade(facade);
        controller2.setStage(stage);
        controller2.setScene(scene);
        controller2.associateListView(bombListCT);
    }
    
    private Image loadImage(String link) {
        try {
            URL url = getClass().getResource(link);
            Image nImage = new Image(url.toExternalForm(), 32, 32, true, true);
            return nImage;

        } catch (NullPointerException | IllegalArgumentException e) {
            throw new NoSuchElementException("Could not load image", e);
        }
    }

    public void initialize(GameMap game) {
    	for (int i = 0; i < game.getHeight(); ++i) {
    		for (int j = 0; j < game.getWidth(); ++j) {
    			Tile tile = game.get(i, j);
    			ImageView view = new ImageView();
    			ImageView view2 = new ImageView();
    			
    			view.imageProperty().bind(
    			Bindings.createObjectBinding(() -> loadImage("/fr/univartois/butinfo/ihm/images/" + tile.getContent().getName()+".png"),
                        tile.getContentProperty())
    			);

    			tile.getExploded().addListener((p,o,n) -> {
    				if (tile.getExploded().get()) {
    					view2.setImage(loadImage("/fr/univartois/butinfo/ihm/images/explosion.png"));
    				} else {
    					view2.setImage(null);
    				}
    			});

    			grid.add(view, j, i);
    			grid.add(view2, j, i);
    		}
    	}
    }
    
    public void finishGame() {
    	pvLab.textProperty().unbind();
		pvLab.setText("Le joueur est mort !");
    	finishedGame = true;
    }
    
    public void updatePlayer(AbstractCharacter player, String url) {
    	ImageView image = new ImageView();
    	image.setImage(loadImage(url));
    	image.yProperty().bind(player.getRowProperty().multiply(32));
    	image.xProperty().bind(player.getColumnProperty().add(1).multiply(32));
    	pane.getChildren().add(image);
    }
    
    public void updateVie(Player player) {
    	pvLab.textProperty().bind(
				player.getHealthProp().asString("Nombre de PV: %d")
			);
    }
    
	public void updateBomb(Player player) {
		bombLab.textProperty().bind(
			player.getBombCount().asString("Bombes restantes : %d")
		);
	}
	
	public void updateEnemyNumber(ObservableList<Enemy> enemyList) {
		ennemiLab.textProperty().bind(
				Bindings.size(enemyList).asString("Nombre d'ennemi: %d")
			);
	}
	
	public void afficherBomb(Player player, AbstractBomb bomb) {
    	ImageView image = new ImageView();
    	image.setImage(loadImage("/fr/univartois/butinfo/ihm/images/bomb.png"));
    	image.setY(player.getRowProperty().get() * 32);

    	image.setX((player.getColumnProperty().get() + 1) * 32);
    	pane.getChildren().add(image);
    	
		bomb.explodedProperty().addListener((p,o,n)-> {
			if (bomb.explodedProperty().get()) {
				pane.getChildren().remove(image);
			}
		});
	}
	
	public void saveBomb(ObservableList<AbstractBomb> bombList) {
		bombListCT = bombList;
	}
    
    @FXML
    private void onRestart() {
    	finishedGame = false;
    	grid.getChildren().clear();
    	pane.getChildren().clear();
    	facade.startGame();
    }

}
