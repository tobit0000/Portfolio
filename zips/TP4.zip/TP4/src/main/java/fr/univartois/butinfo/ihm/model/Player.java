/**
 * Ce logiciel est distribué à des fins éducatives.
 *
 * Il est fourni "tel quel", sans garantie d'aucune sorte, explicite
 * ou implicite, notamment sans garantie de qualité marchande, d'adéquation
 * à un usage particulier et d'absence de contrefaçon.
 * En aucun cas, les auteurs ou titulaires du droit d'auteur ne seront
 * responsables de tout dommage, réclamation ou autre responsabilité, que ce
 * soit dans le cadre d'un contrat, d'un délit ou autre, en provenance de,
 * consécutif à ou en relation avec le logiciel ou son utilisation, ou avec
 * d'autres éléments du logiciel.
 *
 * (c) 2022-2025 Romain Wallon - Université d'Artois.
 * Tous droits réservés.
 */
package fr.univartois.butinfo.ihm.model;

import javafx.beans.binding.Bindings;
import javafx.beans.binding.IntegerBinding;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 * la classe Player représente le personnage du joueur qui utilise l'application.
 *
 * @author Romain Wallon
 *
 * @version 0.1.0
 */
public class Player extends AbstractCharacter {
	ObservableList<AbstractBomb> bombList = FXCollections.observableArrayList();
    /**
     * Construit un nouveau Player.
     */
    public Player(ControllerFacade facade) {    	
        super(facade, 3);
    }
    
    public AbstractBomb getBomb(int index) {
    	return bombList.get(index);
    }
    
    public void removeBomb(int index) {
    	bombList.remove(index);
    }
    
    public ObservableList<AbstractBomb> getBombProp() {
    	return bombList;
    }
    
    public IntegerBinding getBombCount() {
        return Bindings.size(bombList);
    }
    
    public void decHealth() {
    	super.decHealth();
    	if (this.getHealth() <= 0) {
    		// stopper partie
    		facade.finishGame();
    	}
    	
    }

    /*
     * (non-Javadoc)
     *
     * @see fr.univartois.butinfo.ihm.bomberman.model.AbstractCharacter#getName()
     */
    @Override
    public String getName() {
        return "guy";
    }

}
