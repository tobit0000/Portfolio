package fr.univartois.butinfo.ihm.controller;

import fr.univartois.butinfo.ihm.model.AbstractBomb;
import fr.univartois.butinfo.ihm.model.ControllerFacade;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class ChoiceBombController {
    @FXML
    private ListView<AbstractBomb> listView;
    
    @FXML
    private VBox vbInv;
    
    private Stage stage;
    private Scene scene;
    private ControllerFacade facade;

    public void setStage(Stage stage) {
    	this.stage = stage;
    }
    
    public void setScene(Scene scene) {
    	this.scene = scene;
    }
    
    public void setFacade(ControllerFacade facade) {
    	this.facade = facade;
    }
    
    private void updateBombInfo(AbstractBomb bomb) {
    	vbInv.getChildren().clear();

    	Label name = new Label("Nom: " + bomb.getName());
        Label desc = new Label("Description :" + bomb.getDescription());
        Label delay = new Label("Temps avant explosion : " + bomb.getDelay() + "s");

        vbInv.getChildren().addAll(name, desc, delay);
    }
    
    public void associateListView(ObservableList<AbstractBomb> bombList) {
    	 listView.setItems(bombList);
    	 
    	 
    	    listView.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
    	        if (newSelection != null) {
    	        	updateBombInfo(newSelection);
    	        }
    	    });
    }
    
    @FXML
    public void restoreScene() {
        stage.setScene(scene);
    }
    
    @FXML
    public void validateBomb() {
    	facade.poseBomb(listView.getSelectionModel().getSelectedIndex());
    	stage.setScene(scene);
    }
}