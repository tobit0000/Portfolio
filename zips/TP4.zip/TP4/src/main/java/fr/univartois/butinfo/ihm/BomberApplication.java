/**
 * Ce logiciel est distribué à des fins éducatives.
 *
 * Il est fourni "tel quel", sans garantie d'aucune sorte, explicite
 * ou implicite, notamment sans garantie de qualité marchande, d'adéquation
 * à un usage particulier et d'absence de contrefaçon.
 * En aucun cas, les auteurs ou titulaires du droit d'auteur ne seront
 * responsables de tout dommage, réclamation ou autre responsabilité, que ce
 * soit dans le cadre d'un contrat, d'un délit ou autre, en provenance de,
 * consécutif à ou en relation avec le logiciel ou son utilisation, ou avec
 * d'autres éléments du logiciel.
 *
 * (c) 2022-2025 Romain Wallon - Université d'Artois.
 * Tous droits réservés.
 */

package fr.univartois.butinfo.ihm;

import java.io.IOException;

import fr.univartois.butinfo.ihm.controller.BomberController;
import fr.univartois.butinfo.ihm.controller.ChoiceBombController;
import fr.univartois.butinfo.ihm.model.ControllerFacade;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * La classe HelloApplication illustre le fonctionnement d'une {@link Application} JavaFX.
 *
 * @author Romain Wallon
 *
 * @version 0.1.0
 */
public class BomberApplication extends Application {
	public static final int MAX_HAUTEUR = 15;
	public static final int MAX_LARGEUR = 15;
    /**
     * Cette méthode permet d'initialiser l'affichage de la fenêtre de l'application.
     *
     * @param stage La fenêtre (initialement vide) de l'application.
     */
    @Override
    public void start(Stage stage) throws IOException {
        // Il faut d'abord récupérer la description de la vue (au format FXML).
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/univartois/butinfo/ihm/view/bomber-view.fxml"));
        Parent viewContent = fxmlLoader.load();
        
        // Ensuite, on la place dans une Scene...
        Scene scene = new Scene(viewContent, 700, 780);
        // que l'on place elle-même dans la fenêtre.
        stage.setScene(scene);
        
        ControllerFacade facade = new ControllerFacade();
        BomberController controller = fxmlLoader.getController();
        controller.setFacade(facade);
        controller.setScene(scene);
        controller.setStage(stage);
        facade.setController(controller);
        facade.startGame();
        //controller.initialize(game);

        // On peut ensuite donner un titre à la fenêtre.
        stage.setTitle("BomberMan");

        // Enfin, on affiche la fenêtre.
        stage.show();
    }

    /**
     * Cette méthode exécute l'application JavaFX.
     * Pour le cours d'IHM, la méthode {@code main} d'une application JavaFX sera
     * toujours la même : un simple appel à la méthode {@link #launch(String...)}
     * définie dans la classe {@link Application}.
     *
     * @param args Les arguments de la ligne de commande (dont on ne tient pas compte).
     *
     * @see #launch(String...)
     */
    public static void main(String[] args) {
        launch();
    }

}
